package com.springboot.domain;

public enum Role {
    USER, ADMIN
}
