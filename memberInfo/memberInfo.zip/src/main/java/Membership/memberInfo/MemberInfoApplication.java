package Membership.memberInfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MemberInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MemberInfoApplication.class, args);
	}

}
